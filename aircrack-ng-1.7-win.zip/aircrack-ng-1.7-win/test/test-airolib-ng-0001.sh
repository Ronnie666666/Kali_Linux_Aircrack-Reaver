#!/bin/sh

set -ef

"${abs_srcdir}/test-airolib-sqlite.sh" "${abs_builddir}/.."

exit 0

